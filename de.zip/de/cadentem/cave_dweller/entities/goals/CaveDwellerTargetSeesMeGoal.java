package de.cadentem.cave_dweller.entities.goals;

import de.cadentem.cave_dweller.entities.CaveDwellerEntity;
import de.cadentem.cave_dweller.util.Utils;
import java.util.List;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.player.Player;
/* loaded from: CaveDwellerTargetSeesMeGoal.class */
public class CaveDwellerTargetSeesMeGoal extends NearestAttackableTargetGoal<Player> {
    private final CaveDwellerEntity caveDweller;

    public CaveDwellerTargetSeesMeGoal(CaveDwellerEntity mob) {
        super(mob, Player.class, false);
        this.caveDweller = mob;
    }

    public boolean m_8036_() {
        if (this.caveDweller.m_20145_()) {
            return false;
        }
        this.f_26050_ = Utils.getValidTarget(this.caveDweller);
        if (!Utils.isValidTarget(this.f_26050_)) {
            return false;
        }
        return this.caveDweller.isLookingAtMe(this.f_26050_, true);
    }

    public void m_8056_() {
        this.caveDweller.m_6710_(this.f_26050_);
        this.caveDweller.setSpotted(true);
        if (this.f_26050_ != null) {
            this.caveDweller.pickRoll(List.of(Roll.CHASE, Roll.STARE, Roll.STARE, Roll.FLEE));
        }
        super.m_8056_();
    }

    public void m_8041_() {
        super.m_8041_();
    }

    public boolean m_8045_() {
        return Utils.isValidTarget(this.f_26050_);
    }

    public void m_8037_() {
        super.m_8037_();
    }
}