package de.cadentem.cave_dweller.client;

import de.cadentem.cave_dweller.entities.CaveDwellerEntity;
import de.cadentem.cave_dweller.util.Utils;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.constant.DataTickets;
import software.bernie.geckolib.core.animatable.model.CoreGeoBone;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.model.GeoModel;
import software.bernie.geckolib.model.data.EntityModelData;
/* loaded from: CaveDwellerModel.class */
public class CaveDwellerModel extends GeoModel<CaveDwellerEntity> {
    public ResourceLocation getModelResource(CaveDwellerEntity ignored) {
        return new ResourceLocation("cave_dweller", "geo/cave_dweller.geo" + Utils.getTextureAppend() + ".json");
    }

    public ResourceLocation getTextureResource(CaveDwellerEntity ignored) {
        return new ResourceLocation("cave_dweller", "textures/entity/cave_dweller_texture" + Utils.getTextureAppend() + ".png");
    }

    public ResourceLocation getAnimationResource(CaveDwellerEntity ignored) {
        return new ResourceLocation("cave_dweller", "animations/cave_dweller.animation.json");
    }

    public void setCustomAnimations(CaveDwellerEntity animatable, long instanceId, AnimationState<CaveDwellerEntity> animationState) {
        CoreGeoBone head = getAnimationProcessor().getBone("head");
        if (head != null) {
            EntityModelData entityData = (EntityModelData) animationState.getData(DataTickets.ENTITY_MODEL_DATA);
            head.setRotX(entityData.headPitch() * 0.017453292f);
            head.setRotY(entityData.netHeadYaw() * 0.017453292f);
        }
        super.setCustomAnimations(animatable, instanceId, animationState);
    }
}